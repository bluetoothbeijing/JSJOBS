<?php
/**
 * @Copyright Copyright (C) 2009-2010 Ahmad Bilal
 * @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
 * Company:		Buruj Solutions
 + Contact:		www.burujsolutions.com , info@burujsolutions.com
 * Created on:	Nov 22, 2010
 ^
 + Project: 	JS Jobs
 ^ 
 */

// no direct access
defined('_JEXEC') or die('Restricted access');
use Joomla\CMS\Factory;
use Joomla\CMS\Router\Route;	


class modJSJobsLoginHelper
{
	static function getReturnURL($params, $type)
	{
		if($itemid =  $params->get($type)){  
			if ($type == 'login'){ // login
				$redirectpage = $params->get('login');
				if ( $redirectpage == 'jsjobs'){ // jsjobs
					$link = 'index.php?option=com_jsjobs&c=jsjobs&view=employer&layout=successfullogin';
					$url = Route::_($link.'&Itemid='.$itemid, false);
				}else{ // joomla
					$menu = Factory::getApplication()->getMenu();
					$default = $menu->getDefault();
					$uri = Factory::getURI( $default->link.'&Itemid='.$default->id );
					$url = $uri->toString(array('path', 'query', 'fragment'));
				}
			}else{ // logout
				//$jsite = new JSite;
				$menu = Factory::getApplication()->getMenu();
				$item = $menu->getItem($itemid); //var_dump($menu);die;
				if ($item)
					$url = Route::_($item->link.'&Itemid='.$itemid, false);
				else{ // stay on the same page
					$uri = Factory::getURI();
					$url = $uri->toString(array('path', 'query', 'fragment'));
				}
			}	
		}
		else{ // stay on the same page
			$uri = Factory::getURI();
			$url = $uri->toString(array('path', 'query', 'fragment'));
		}

		return base64_encode($url);
	}

	static function getType()
	{
		$user = Factory::getUser();
		return (!$user->get('guest')) ? 'logout' : 'login';
	}
}
