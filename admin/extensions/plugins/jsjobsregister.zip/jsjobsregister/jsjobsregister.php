<?php
/**
 + Created by:	Ahmad Bilal
 * Company:		Buruj Solutions
 + Contact:		www.burujsolutions.com , info@burujsolutions.com
				www.joomsky.com, ahmad@joomsky.com
 * Created on:	Dec 19, 2010
 ^
 + Project: 		JS Jobs 
 * File Name:	Pplugin/jsjobregister.php
 ^ 
 * Description: Plugin for JS Jobs
 ^ 
 * History:		NONE
 ^ 
 */

defined( '_JEXEC' ) or die( 'Restricted access' );
use Joomla\CMS\Factory;
use Joomla\CMS\Version;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;	
use Joomla\CMS\Component\ComponentHelper;


if(!defined('DS')){
   define('DS',DIRECTORY_SEPARATOR);
}

class plgSystemJSJobsRegister extends JPlugin
{
		function onUserBeforeSave($user,$isnew){
			//echo'<pre>';print_r($user);echo '</pre>';
			if( $isnew )
			{ 
				if(isset($_POST['userrole'])){
					$mainframe = Factory::getApplication();
					$componentPath = JPATH_SITE.'/components/com_jsjobs';
                                        if(file_exists($componentPath.'/JSApplication.php')){
                                            require_once $componentPath.'/JSApplication.php';
                                            $db = Factory::getDBO();
                                            $query = "SELECT  configvalue FROM  #__js_job_config where configname='user_registration_captcha' OR configname = 'captchause' ORDER BY configname";
                                            $db->setQuery( $query );
                                            $config =$db->loadObjectList();
                                            $redirect = 0;
                                            // $captchaplugin = JPluginHelper::getPlugin('captcha', 'recaptcha_invisible');
                                            $captchaparam = ComponentHelper::getParams('com_users');
  											$regcaptchatype = $captchaparam->get('captcha');
                                            if(!isset($_POST['notcaptcha']))
                                            if($config[1]->configvalue==1){
                                            	if($config[0]->configvalue == 0){
                                            		$captchaconfig = Factory::getConfig();
                                					$defaultcaptchtype = $captchaconfig->get( 'captcha'); // getting default captcha;
                                            		if($defaultcaptchtype == 'recaptcha' && $regcaptchatype == 0){
	                                                    $captcha = JCaptcha::getInstance('recaptcha', array('namespace' => 'dynamic_recaptcha_1'));
										                if($captcha){
										                    $get_answer = Factory::getApplication()->input->get("g-recaptcha-response", "");
										                    $answer = $captcha->checkAnswer($get_answer); 
										                    if(!$answer) {
										                        $redirect = 1;
										                    }
										                }
									                }elseif($defaultcaptchtype == 'recaptcha_invisible' && $regcaptchatype == 0){
									                	$post = Factory::getApplication()->input->post->getArray();
	                                                	$result = JSModel::getJSModel('common')->checkRecaptchaV3PostValue($post['g-recaptcha-response']);
								                        if(!$result){
								                            $redirect = 1;
								                        }	
									                }                                           
                                                }else{
                                                    if(!JSModel::getJSModel('common')->performChecks()){
                                                        $redirect = 1;
                                                    }
                                                }
                                                if($redirect == 1){
                                                    $msg = Text::_('ERROR_INCORRECT_CAPTCHA_CODE');
                                                    $link = "index.php?option=com_jsjobs&c=common&view=common&layout=userregister&userrole=".$_POST['userrole'];
                                                    $mainframe->redirect(Route::_($link), $msg);

                                                }
                                            }
                                        }
				   return true;
				}
			}

		}
		function onAfterStoreUser($user, $isnew, $success, $msg){ //j 1.5
			if( $isnew )
			{
				
				if(isset($_POST['userrole'])){
					$db = &Factory::getDBO();
					$created = date('Y-m-d H:i:s');
					$userid = (int) $user['id'];
					$userrole = (int) $user['userrole'];
					$query = "INSERT INTO #__js_job_userroles (uid,role,dated) VALUES (".$userid.", ".$userrole.", '".$created."')";
					$db->setQuery( $query );
					$db->execute();

					$componentAdminPath = JPATH_ADMINISTRATOR.'/components/com_jsjobs';
					$componentPath = JPATH_SITE.'/components/com_jsjobs';
                    if(file_exists($componentPath.'/JSApplication.php')){
                        require_once $componentPath.'/JSApplication.php';
                        $result = JSModel::getJSModel('userrole')->addUser($userrole,$userid);
                    }
				}
			}
		}

		function onUserAfterSave($user, $isnew, $success, $msg){ //j 1.6 +
			if( $isnew ){
				$mainframe = Factory::getApplication();
				if(isset($_POST['userrole']) && is_numeric($_POST['userrole'])){
					$userrole = $_POST['userrole'];
					$userid = (int) $user['id'];
					$db = Factory::getDBO();
					$created = date('Y-m-d H:i:s');
					$query = "INSERT INTO #__js_job_userroles (uid,role,dated) VALUES (".$userid.", ".$userrole.", '".$created."')";
					$db->setQuery( $query );
					$db->execute();
					$componentAdminPath = JPATH_ADMINISTRATOR.'/components/com_jsjobs';
					$componentPath = JPATH_SITE.'/components/com_jsjobs';
                    if(file_exists($componentPath.'/JSApplication.php')){
                        require_once $componentPath.'/JSApplication.php';
                        $result = JSModel::getJSModel('userrole')->addUser($userrole,$userid);
						if(isset($_POST['fromjsjobsregister']) && $_POST['fromjsjobsregister'] == 1){
							$register_redirect = '';
							if($userrole == 1){ // Employer
								$register_redirect = JSModel::getJSModel('configurations')->getConfigValue('register_employer_redirect_page');
							}else{ // Jobseeker
								$register_redirect = JSModel::getJSModel('configurations')->getConfigValue('register_jobseeker_redirect_page');			
							}
							if($result == 1){
								$msg = Text::_('User has been saved successfully');
								$status = 'Success';
							}else{
								$msg = Text::_('User has not been saved successfully');
								$status = 'Error';
							}
							$app = Factory::getApplication();
							$app->enqueueMessage($msg, 'fail');
							$app->redirect($register_redirect);
						}
					}
				}

			}
			
		}

	   function onUserAfterDelete( $user, $success, $msg )
		{
			$db = &Factory::getDBO();
			if(is_numeric($user['id'])){
				$userid = (int) $user['id'];
				$query = 'DELETE FROM #__js_job_userroles WHERE uid ='.$userid;
				$db->setQuery( $query );
				$db->execute();
				return true;
			}	
		}

		function onAfterDispatch()
        {
			$document = Factory::getDocument();
			$content = $document->getBuffer('component');
			$option = Factory::getApplication()->input->get('option');
			$view = Factory::getApplication()->input->get('view');
	        $lang = Factory::getLanguage();
	        $lang->load('com_jsjobs', JPATH_ADMINISTRATOR, null, true);
			$html = $this->getRoleHTML();
//			$lang = Factory::getLanguage();
//			$lang->load('plg_content_jsjobsregister', JPATH_ADMINISTRATOR);

			$version = new Version;
			$joomla = $version->getShortVersion();
			$jversion = substr($joomla,0,3);


			$newcontent = "";
			if($option == 'com_user' || $option == 'com_users'){
				if($view == 'register' || $view == 'registration'){
					$document = Factory::getDocument();
					$content = $document->getBuffer('component');
					$html = $this->getRoleHTML();
					$newcontent = "";
					if($jversion == '1.5')	$checkcontent = '<button class="button validate" type="submit">'.Text::_('REGISTER').'</button>';
					elseif($jversion == '2.5') $checkcontent = '<button type="submit" class="validate">';
					else $checkcontent = '<button type="submit" class="btn btn-primary validate">';

					$newcontent = str_replace($checkcontent,$html.$checkcontent,$content);
		
					if($newcontent!="")	{
						$document->setBuffer($newcontent,'component');
					}
				}
			}
        }
		function getRoleHTML()
		{
                    if(!Factory::getApplication()->isClient('administrator')){
			jimport( 'joomla.html.parameter' );
			$plugin 	= JPluginHelper::getPlugin('system', 'jsjobsregister');
			$version = new Version;
			$joomla = $version->getShortVersion();
			$jversion = substr($joomla,0,3);
			if($jversion == '2.5'){
				$params   	= json_decode($plugin->params);
				$this->params   	= new JParameter($plugin->params);
			}else{
				$this->params   	= new JRegistry();
				$this->params->loadString($plugin->params);
			} 
	        $lang = Factory::getLanguage();
	        $lang->load('com_jsjobs', JPATH_ADMINISTRATOR, null, true);
//			JPlugin::loadLanguage( 'plg_system_jsjobsregister', JPATH_ADMINISTRATOR );

			$componentAdminPath = JPATH_ADMINISTRATOR.'/components/com_jsjobs';
			$componentPath = JPATH_SITE.'/components/com_jsjobs';
                        if(file_exists($componentPath.'/JSApplication.php')){
                            require_once $componentPath.'/JSApplication.php';
                            $can_employer_register = JSModel::getJSModel('employer')->userCanRegisterAsEmployer();

                            $userregisterinrole = $this->params->get('userregisterinrole');
                            //$userregisterinrole = $params->userregisterinrole;

                            $jsrole = Factory::getApplication()->input->get('jsrole');
                            if($userregisterinrole == 2) $jsrole = 1; // enforce employer
                            elseif($userregisterinrole == 3) $jsrole = 2; // enforce jobseeker

                            if($can_employer_register != true) $jsrole = 2; // enforce jobseeker

                            if ($jsrole == 1){ // employer
                                $rolehtml = "<input type='hidden' name='userrole' value='1'><input type='hidden' name='notcaptcha' value='1'>".Text::_('Employer');
                                $returnvalue = "<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
                                                                      <tr><td width=\"120\"  >".Text::_('Role').":</td><td >".$rolehtml."</td></tr></table>";
                            }elseif($jsrole == 2){
                            	$rolehtml = "<input type='hidden' name='notcaptcha' value='1'><input type='hidden' name='userrole' value='2'>".Text::_('Job Seeker');                                    	
                                $returnvalue = "<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
                                                                      <tr><td width=\"120\"  >".Text::_('Role').":</td><td >".$rolehtml."</td></tr></table>";
							}else{
                                    $rolehtml = "<select name='userrole'>
                                                            <option value='1'>".Text::_('Employer')."</option>
                                                            <option value='2'>".Text::_('Job Seeker')."</option>
                                                    </select><input type='hidden' name='notcaptcha' value='1'>";
                                    $returnvalue = "<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">
                                                                      <tr><td width=\"120\"  >".Text::_('Role').":</td><td >".$rolehtml."</td></tr></table>";
                                  	include_once JPATH_ADMINISTRATOR.'/components/com_jsjobs/include/classes/customfields.php';
		                            $fieldordering = JSModel::getJSModel('customfields')->getFieldsOrdering(14, true); // gdpr fields
		                            $obj = new customfields();
		                            foreach($fieldordering AS $field){
		                            	$array = $obj->formCustomFields($field , NULL , NULL , 'gdpr_fields');
		                            	$returnvalue .= $array;
		                            }
                            }					
                            return $returnvalue;				
                        }
                    }
		}
		
}
?>
